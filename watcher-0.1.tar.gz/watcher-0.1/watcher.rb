require 'daemonize'
require 'file/tail'

files   = %w{/tmp/log1.txt /tmp/log2.txt /tmp/log3.txt}
pattern = "cannot connect"

class Watcher
  include Daemonize

  def initialize(files, pattern)
    @files   = files
    @pattern = pattern
  end

  def start()
    #daemonize()
    block_on_watchers(start_watchers(@pattern, @files))
  end

  def start_scanner(pattern, filename, &callback)
    while !File.exists?(filename)
      sleep(1)
    end

    while true
      File.open(filename) do |log|
        log.seek(IO::SEEK_END)
        log.extend(File::Tail)
        log.interval = 0.25
        log.backward(0)
        log.tail do |line|
          if line =~ /#{pattern}/i
            if block_given?
              callback.call(filename, line)
              break
            end
          end
        end
      end
    end
  end

  def print_filename(filename, line)
    puts "#{filename}: #{line}"
  end

  def start_watchers(pattern, files)
    threads = []
    files.each do |file|
      threads << Thread.new do
        start_scanner(pattern, file) do |filename, line|
          # begin critical section (all other threads are stopped)
          Thread.critical = true
          print_filename(filename, line)       
          sleep 10
          Thread.critical = false
          # end critical section (other threads resume)
        end
      end
    end
    return threads
  end

  def block_on_watchers(threads)
    threads.each do |thread|
      thread.join
    end
  end
end

watcher = Watcher.new(files, pattern)
watcher.start
